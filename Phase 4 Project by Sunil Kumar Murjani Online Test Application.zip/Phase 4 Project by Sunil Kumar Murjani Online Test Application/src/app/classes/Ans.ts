export class Ans{
    constructor(
        public qid:number,
        public  answer :string
    ){

    }
}